const config=require('../config');
let instance=null,pending=null;
async function connection(){
 if(!config.cloudEnv)throw Error('当前为本机体验');
 if(instance)return instance;
 if(pending)return pending;
 pending=(async()=>{if(!wx.cloud)throw Error('请更新微信后再打开');let cloud;
 if(config.resourceAppid){if(!wx.cloud.Cloud)throw Error('当前微信不支持共享云环境');cloud=new wx.cloud.Cloud({resourceAppid:config.resourceAppid,resourceEnv:config.cloudEnv});await cloud.init();}
 else{wx.cloud.init({env:config.cloudEnv,traceUser:false});cloud=wx.cloud;}
 instance=cloud;return cloud;})().catch(error=>{pending=null;throw Object.assign(Error(config.resourceAppid?'共享云环境未连接：请确认授权':'云环境未连接，请检查环境ID与小游戏关联'),{code:'CLOUD_FAILED'});});
 return pending;
}
module.exports={connection};
